import Database from "better-sqlite3";
import path from "path";
import fs from "fs";

const dir = path.join(process.cwd(),"data");
if (!fs.existsSync(dir)) fs.mkdirSync(dir,{recursive:true});
const db = new Database(path.join(dir,"quran-center.db"));
db.pragma("journal_mode = WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS admins(id INTEGER PRIMARY KEY AUTOINCREMENT,password TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS teachers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,phone TEXT,password TEXT);
CREATE TABLE IF NOT EXISTS halaqat(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,teacher_id INTEGER,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS students(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,national_id TEXT UNIQUE NOT NULL,birth_date TEXT,address TEXT,level TEXT,rating TEXT,notes TEXT,halaqa_id INTEGER);
`);
const admin = db.prepare("SELECT id FROM admins LIMIT 1").get();
if (!admin) db.prepare("INSERT INTO admins(password) VALUES (?)").run("123456");
export default db;
