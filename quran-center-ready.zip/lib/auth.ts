import { cookies } from "next/headers";
export async function isAdmin(){return (await cookies()).get("admin_session")?.value==="1";}
