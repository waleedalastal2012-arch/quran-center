import "./globals.css";
import Link from "next/link";
export default function RootLayout({children}:{children:React.ReactNode}){
 return <html lang="ar" dir="rtl"><body>
 <nav><div className="container" style={{display:"flex",justifyContent:"space-between",alignItems:"center",paddingTop:18,paddingBottom:18}}>
 <strong style={{color:"#166534",fontSize:20}}>منصة تعليم القرآن الكريم</strong>
 <div style={{display:"flex",gap:18}}><Link href="/">الرئيسية</Link><Link href="/learn">ابدأ التعلم</Link><Link href="/admin">لوحة الأدمن</Link></div>
 </div></nav>{children}</body></html>
}