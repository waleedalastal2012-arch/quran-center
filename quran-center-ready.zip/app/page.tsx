import Link from "next/link";
export default function Home(){return <>
<main><section style={{textAlign:"center",padding:"80px 20px 55px",background:"linear-gradient(180deg,#eef7ee,#f5f7f2)"}}><div className="container">
<div style={{fontSize:56}}>📖</div><h1 style={{fontSize:"clamp(32px,6vw,58px)",margin:"18px 0",color:"#14532d"}}>أهلاً بك في منصة تعليم القرآن الكريم</h1>
<p style={{fontSize:20,lineHeight:1.9,maxWidth:720,margin:"0 auto 28px",color:"#4b5563"}}>منصة لخدمة كتاب الله وتنظيم التعليم والتحفيظ ومتابعة الطلاب والمحفظين.</p><Link className="btn" href="/learn">ابدأ التعلم</Link>
</div></section><section className="container" style={{paddingTop:55}}><div className="card">
<h2 style={{color:"#166534"}}>أهلاً بكم في مركز الشهيد يحيى أبو عمر لتحفيظ القرآن الكريم والسنة</h2>
<p style={{fontSize:18,lineHeight:2}}>مركز يهتم بتعليم القرآن الكريم وتحفيظه، وغرس محبة كتاب الله في نفوس الناشئة، وتنمية الأخلاق والقيم الإسلامية من خلال برامج تعليمية وإيمانية هادفة. نسعى إلى توفير بيئة تربوية تساعد الطلاب على الارتقاء في حفظ القرآن وفهمه والعمل به.</p>
</div></section></main>
<footer><div className="container" style={{textAlign:"center"}}><h3>مركز الشهيد يحيى أبو عمر لتحفيظ القرآن الكريم والسنة</h3><p>العنوان: مخيم حمد</p><p>للتواصل والتبرع: <strong>0592483284</strong></p></div></footer>
</>}
